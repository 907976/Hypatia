import os
import struct
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

class CCSaveEditor:
    """
    A utility class to parse, modify, and serialize encrypted Castle Crashers Remastered save data.
    """
    GLOBAL_SIZE = 64
    CHAR_SIZE = 48
    NUM_CHARS = 42
    SAVE_LENGTH = 2128  # Decrypted save length with checksum

    # Character block offsets (relative to character start offset)
    OFF_UNLOCK = 0
    OFF_LEVEL = 1
    OFF_XP = 2
    OFF_WEAPON = 6
    OFF_PET = 7
    OFF_STR = 8
    OFF_DEF = 9
    OFF_MAG = 10
    OFF_AGI = 11
    OFF_NORMAL_LVL = 12
    OFF_POTIONS = 15
    OFF_BOMBS = 16
    OFF_SANDWICHES = 17
    OFF_NON_CONSUMABLE = 18
    OFF_GOLD = 19
    OFF_INSANE_UNLOCKED = 23
    OFF_INSANE_LVL = 24
    OFF_SKULL = 27

    # Global block offsets
    OFF_GLOBAL_VIBRATION = 1
    OFF_GLOBAL_MUSIC_VOL = 3
    OFF_GLOBAL_GORE = 5
    OFF_GLOBAL_BOB_TIME = 48
    OFF_GLOBAL_BOB_CHAR = 52

    CHARACTERS = [
        "Green Knight", "Red Knight", "Blue Knight", "Orange Knight", "Gray Knight",
        "Barbarian", "Thief", "Fencer", "Beekeeper", "Industrialist", "Alien Hominid",
        "The King", "The Brute", "Snakey", "Saracen", "Royal Guard", "Stoveface",
        "Peasant", "Bear", "Necromancer", "Conehead", "Civilian", "Open-face Gray Knight",
        "Fire Demon", "Skeleton", "Iceskimo", "Ninja", "Cultist", "Pink Knight",
        "Blacksmith", "Hatty", "Paint Junior",
        "Custom 1", "Custom 2", "Custom 3", "Custom 4", "Custom 5",
        "Custom 6", "Custom 7", "Custom 8", "Custom 9", "Custom 10"
    ]

    WEAPONS = [
        "Skinny Sword", "Skinny Sword (Alt)", "Skinny Sword (Alt 2)", "Thin Sword", "Thick Sword",
        "Pumpkin Peeler", "Gladiator Sword", "Butcher Knife", "Half Sword", "Carrot",
        "Thief Sword", "Gold Sword", "Dual Prong Sword", "Zigzag", "Playdo Pasta Maker",
        "Falchion", "Pointy Sword", "Chewed Up Sword", "Fencer's Foil", "Barbarian Axe",
        "Pitchfork", "Curved Sword", "Key Sword", "Apple Peeler", "Rubber Handle Sword",
        "Mace", "Club", "Ugly Mace", "Refined Mace", "Fish", "Wrapped Sword",
        "Skeletor Mace", "Clunky Mace", "Snakey Mace", "Rat Beating Bat",
        "Black Morning Star", "King's Mace", "Meat Tenderizer", "Leaf", "Sheathed Sword",
        "Practice Foil", "Twig", "Leafy Twig", "Light Saber", "Staff", "Wooden Spoon",
        "Bone Leg", "Alien Gun", "Fishing Spear", "Lance", "Sai", "Unicorn Horn",
        "Ribeye", "Kielbasa", "Lobster", "Umbrella", "Broad Ax", "Evil Sword",
        "Ice Sword", "Candlestick", "Panic Mallet", "Fishing Rod", "Wrench",
        "NG Lollipop", "Gold Skull Mace", "NG Gold Sword", "Chainsaw", "Broad Spear",
        "Glowstick", "Chicken Stick", "Demon Sword", "Broccoli Sword", "Man Catcher",
        "Wooden Mace", "Ninja Claw", "Buffalo Mace", "Electric Eel", "Scissors",
        "Dinner Fork", "Cattle Prod", "Lightning Bolt", "2x4", "Wooden Sword",
        "Cardboard Tube", "Emerald Sword", "Hammer", "Pencil", "Invisible Sword",
        "Invisible Sword 2", "Invisible Sword 3", "Invisible Sword 4", "Invisible Sword 5",
        "Invisible Sword 6", "Invisible Map", "Invisible Horn", "Invisible Arrow",
        "Invisible Shovel", "Map", "Horn", "Arrow", "Shovel"
    ]

    PETS = [
        "None", "Cardinal", "Owlet", "Rammy", "Frogglet", "Monkeyface", "BiPolar Bear",
        "Bitey Bat", "Yeti", "Troll", "Snailburt", "Giraffey", "Zebra", "Meowburt",
        "Pazzo", "Burly Bear", "Hawkster", "Snoot", "Piggy", "Spiny", "Scratchpaw",
        "Seahorse", "Chicken", "Install Ball", "Mr. Buddy", "Sherbert", "Pelter",
        "Dragonhead", "Beholder", "Golden Whale"
    ]

    LEVELS = [
        "Checkpoint 0", "Castle Keep", "Barbarian Boss", "Thieves' Forest", "Catfish",
        "Pipistrello's Cave", "Parade", "Cyclops' Fortress", "Lava World",
        "Industrial Castle", "Pirate Ship", "Desert Chase", "Sand Castle Roof",
        "Corn Boss", "Medusa's Lair", "Full Moon", "Ice Castle", "Final Battle"
    ]

    RELICS = [
        "Compass (Normal)", "Wheel (Normal)", "Telescope (Normal)", "Horn (Normal)",
        "Compass (Insane)", "Wheel (Insane)", "Telescope (Insane)", "Horn (Insane)"
    ]

    def __init__(self, filepath, steam_id):
        self.filepath = filepath
        self.steam_id = str(steam_id).strip()
        self.decrypted_data = None

    @staticmethod
    def build_key(steam_id_str):
        """Constructs the 24-byte Blowfish key dynamically from the Steam ID64."""
        sid = int(steam_id_str)
        lo = sid & 0xFFFFFFFF
        hi = (sid >> 32) & 0xFFFFFFFF

        key = bytearray(24)
        struct.pack_into("<I", key, 0, 0xb9128343)
        struct.pack_into("<I", key, 4, 0x7e636609)
        struct.pack_into("<I", key, 8, 0x127aac36)
        struct.pack_into("<I", key, 12, 0x563e6167)
        struct.pack_into("<Q", key, 16, 0x019fd45372723839)

        struct.pack_into("<H", key, 0, (hi >> 16) & 0xFFFF)
        struct.pack_into("<H", key, 5, (lo >> 16) & 0xFFFF)
        struct.pack_into("<H", key, 15, lo & 0xFFFF)
        struct.pack_into("<H", key, 19, hi & 0xFFFF)

        return bytes(key)

    @staticmethod
    def swap_endian(data):
        """Swaps the endianness of every 4-byte chunk in the byte stream."""
        return b''.join([data[i:i+4][::-1] for i in range(0, len(data), 4)])

    def load(self):
        """Decrypts and loads the save file using the Steam ID."""
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"File not found: {self.filepath}")

        with open(self.filepath, "rb") as f:
            encrypted_data = f.read()

        if len(encrypted_data) != self.SAVE_LENGTH:
            raise ValueError(f"Invalid file size. Expected {self.SAVE_LENGTH} bytes, got {len(encrypted_data)}.")

        key = self.build_key(self.steam_id)
        
        # Swapping endianness is required because standard Blowfish is big-endian
        # but the game's implementation operates on little-endian uint32s.
        to_dec = self.swap_endian(encrypted_data)
        
        cipher = Cipher(algorithms.Blowfish(key), modes.ECB(), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted_raw = decryptor.update(to_dec) + decryptor.finalize()
        
        self.decrypted_data = bytearray(self.swap_endian(decrypted_raw))

        # Validate internal checksum
        stored_checksum = struct.unpack("<I", self.decrypted_data[-4:])[0]
        calculated_checksum = self.calculate_checksum(self.decrypted_data, self.SAVE_LENGTH - 4)
        if stored_checksum != calculated_checksum:
            raise ValueError(f"Checksum mismatch. Stored: {stored_checksum}, Calculated: {calculated_checksum}")

    @staticmethod
    def calculate_checksum(data, length):
        """Computes the custom rolling checksum used by Castle Crashers."""
        local_8 = 0
        local_c = 0
        uVar4 = 0xD971
        i = 0

        while i + 1 < length:
            bVar5 = ((uVar4 >> 8) ^ data[i]) & 0xFF
            sVar2 = (((bVar5 + uVar4) & 0xFFFF) * 0xCE6D + 0x58BF) & 0xFFFF
            local_8 += bVar5

            uVar1 = ((sVar2 >> 8) ^ data[i + 1]) & 0xFF
            uVar4 = (((uVar1 + sVar2) & 0xFFFF) * 0xCE6D + 0x58BF) & 0xFFFF
            local_c += uVar1

            i += 2

        uVar6 = 0
        if i < length:
            uVar6 = ((uVar4 >> 8) ^ data[i]) & 0xFF

        return (local_8 + local_c + uVar6) & 0xFFFFFFFF

    def _char_offset(self, char_index):
        return self.GLOBAL_SIZE + char_index * self.CHAR_SIZE

    @staticmethod
    def count_bits_3_bytes(data, offset):
        """Counts set bits in 3 consecutive bytes starting at offset."""
        count = 0
        for i in range(3):
            b = data[offset + i]
            while b:
                count += b & 1
                b >>= 1
        return count

    @staticmethod
    def write_bits_3_bytes(data, offset, total):
        """Writes given number of set bits across 3 consecutive bytes starting at offset."""
        for i in range(3):
            if total >= 8:
                data[offset + i] = 0xFF
                total -= 8
            elif total > 0:
                data[offset + i] = (1 << total) - 1
                total = 0
            else:
                data[offset + i] = 0

    def get_character_data(self, char_index):
        """Extracts stats and attributes for a specific character."""
        if char_index < 0 or char_index >= len(self.CHARACTERS):
            raise IndexError("Invalid character index.")

        off = self._char_offset(char_index)
        
        unlocked = self.decrypted_data[off + self.OFF_UNLOCK] != 0
        level = self.decrypted_data[off + self.OFF_LEVEL] + 1
        xp = struct.unpack(">i", self.decrypted_data[off + self.OFF_XP : off + self.OFF_XP + 4])[0]
        weapon = self.decrypted_data[off + self.OFF_WEAPON]
        pet = self.decrypted_data[off + self.OFF_PET]
        strength = self.decrypted_data[off + self.OFF_STR]
        defense = self.decrypted_data[off + self.OFF_DEF]
        magic = self.decrypted_data[off + self.OFF_MAG]
        agility = self.decrypted_data[off + self.OFF_AGI]
        normal_lvl = self.count_bits_3_bytes(self.decrypted_data, off + self.OFF_NORMAL_LVL)
        potions = self.decrypted_data[off + self.OFF_POTIONS]
        bombs = self.decrypted_data[off + self.OFF_BOMBS]
        sandwiches = self.decrypted_data[off + self.OFF_SANDWICHES]
        non_consumables_val = self.decrypted_data[off + self.OFF_NON_CONSUMABLE]
        relics = [(non_consumables_val >> i) & 1 == 1 for i in range(8)]
        gold = struct.unpack(">i", self.decrypted_data[off + self.OFF_GOLD : off + self.OFF_GOLD + 4])[0]
        insane_unlocked = self.decrypted_data[off + self.OFF_INSANE_UNLOCKED] != 0
        insane_lvl = self.count_bits_3_bytes(self.decrypted_data, off + self.OFF_INSANE_LVL)
        skull = self.decrypted_data[off + self.OFF_SKULL]

        return {
            "name": self.CHARACTERS[char_index],
            "unlocked": unlocked,
            "level": level,
            "xp": xp,
            "weapon": weapon,
            "pet": pet,
            "strength": strength,
            "defense": defense,
            "magic": magic,
            "agility": agility,
            "normal_lvl": normal_lvl,
            "potions": potions,
            "bombs": bombs,
            "sandwiches": sandwiches,
            "relics": relics,
            "gold": gold,
            "insane_unlocked": insane_unlocked,
            "insane_lvl": insane_lvl,
            "skull": skull
        }

    def set_character_data(self, char_index, gold=None, level=None, xp=None, unlocked=None, strength=None, defense=None, magic=None, agility=None, weapon=None, pet=None, normal_lvl=None, insane_unlocked=None, insane_lvl=None, skull=None, potions=None, bombs=None, sandwiches=None, relics=None):
        """Updates attributes for a character inside the buffer."""
        if char_index < 0 or char_index >= len(self.CHARACTERS):
            raise IndexError("Invalid character index.")

        off = self._char_offset(char_index)

        if unlocked is not None:
            self.decrypted_data[off + self.OFF_UNLOCK] = 0x80 if unlocked else 0x00
        if level is not None:
            self.decrypted_data[off + self.OFF_LEVEL] = max(1, min(99, level)) - 1
        if xp is not None:
            struct.pack_into(">i", self.decrypted_data, off + self.OFF_XP, xp)
        if weapon is not None:
            self.decrypted_data[off + self.OFF_WEAPON] = max(0, min(255, weapon))
        if pet is not None:
            self.decrypted_data[off + self.OFF_PET] = max(0, min(255, pet))
        if strength is not None:
            self.decrypted_data[off + self.OFF_STR] = max(0, min(25, strength))
        if defense is not None:
            self.decrypted_data[off + self.OFF_DEF] = max(0, min(25, defense))
        if magic is not None:
            self.decrypted_data[off + self.OFF_MAG] = max(0, min(25, magic))
        if agility is not None:
            self.decrypted_data[off + self.OFF_AGI] = max(0, min(25, agility))
        if normal_lvl is not None:
            self.write_bits_3_bytes(self.decrypted_data, off + self.OFF_NORMAL_LVL, normal_lvl)
        if potions is not None:
            self.decrypted_data[off + self.OFF_POTIONS] = max(0, min(255, potions))
        if bombs is not None:
            self.decrypted_data[off + self.OFF_BOMBS] = max(0, min(255, bombs))
        if sandwiches is not None:
            self.decrypted_data[off + self.OFF_SANDWICHES] = max(0, min(255, sandwiches))
        if relics is not None:
            val = 0
            for i, r in enumerate(relics):
                if r:
                    val |= (1 << i)
            self.decrypted_data[off + self.OFF_NON_CONSUMABLE] = val
        if gold is not None:
            struct.pack_into(">i", self.decrypted_data, off + self.OFF_GOLD, gold)
        if insane_unlocked is not None:
            self.decrypted_data[off + self.OFF_INSANE_UNLOCKED] = 0x01 if insane_unlocked else 0x00
        if insane_lvl is not None:
            self.write_bits_3_bytes(self.decrypted_data, off + self.OFF_INSANE_LVL, insane_lvl)
        if skull is not None:
            self.decrypted_data[off + self.OFF_SKULL] = skull

    def get_global_settings(self):
        """Extracts global settings (Gore, Vibration, Music Volume, Back Off Barbarian high score)."""
        vibration = self.decrypted_data[self.OFF_GLOBAL_VIBRATION] != 0
        music_vol = self.decrypted_data[self.OFF_GLOBAL_MUSIC_VOL]
        gore = self.decrypted_data[self.OFF_GLOBAL_GORE] != 0
        bob_time = struct.unpack("<i", self.decrypted_data[self.OFF_GLOBAL_BOB_TIME : self.OFF_GLOBAL_BOB_TIME + 4])[0]
        bob_char = struct.unpack("<i", self.decrypted_data[self.OFF_GLOBAL_BOB_CHAR : self.OFF_GLOBAL_BOB_CHAR + 4])[0]

        return {
            "vibration": vibration,
            "music_vol": music_vol,
            "gore": gore,
            "bob_time": bob_time,
            "bob_char": bob_char
        }

    def set_global_settings(self, vibration=None, music_vol=None, gore=None, bob_time=None, bob_char=None):
        """Updates global settings inside the header block."""
        if vibration is not None:
            self.decrypted_data[self.OFF_GLOBAL_VIBRATION] = 1 if vibration else 0
        if music_vol is not None:
            self.decrypted_data[self.OFF_GLOBAL_MUSIC_VOL] = max(0, min(10, music_vol))
        if gore is not None:
            self.decrypted_data[self.OFF_GLOBAL_GORE] = 1 if gore else 0
        if bob_time is not None:
            struct.pack_into("<i", self.decrypted_data, self.OFF_GLOBAL_BOB_TIME, bob_time)
        if bob_char is not None:
            struct.pack_into("<i", self.decrypted_data, self.OFF_GLOBAL_BOB_CHAR, bob_char)

    def set_global_data(self, unlock_pets=False, unlock_weapons=False, enable_items=False, unlock_arenas=False):
        """Modifies settings inside the 64-byte global header block."""
        if unlock_pets:
            # Unlock all animal orbs
            self.decrypted_data[8] = 0xFE
            for i in range(9, 12):
                self.decrypted_data[i] = 0xFF
        
        if unlock_arenas:
            # Unlock all arena maps (setting bit 0 on offset 8 in addition to pets)
            self.decrypted_data[8] |= 0x01

        if enable_items:
            # Enable Bow, Boomerang, Shovel
            self.decrypted_data[12] = 0x4E

        if unlock_weapons:
            # Unlock all main weapons (18 to 30)
            for i in range(18, 31):
                self.decrypted_data[i] = 0xFF
            # Unlock all DLC weapons (29 to 36)
            for i in range(29, 37):
                self.decrypted_data[i] = 0xFF

    def save(self, output_path=None):
        """Recalculates the checksum, encrypts, and writes the save data back to disk."""
        target = output_path if output_path else self.filepath

        # Update rolling checksum
        checksum_val = self.calculate_checksum(self.decrypted_data, self.SAVE_LENGTH - 4)
        struct.pack_into("<I", self.decrypted_data, self.SAVE_LENGTH - 4, checksum_val)

        # Encrypt data
        key = self.build_key(self.steam_id)
        to_enc = self.swap_endian(bytes(self.decrypted_data))
        
        cipher = Cipher(algorithms.Blowfish(key), modes.ECB(), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted_raw = encryptor.update(to_enc) + encryptor.finalize()
        
        encrypted_final = self.swap_endian(encrypted_raw)

        with open(target, "wb") as f:
            f.write(encrypted_final)

if __name__ == "__main__":
    import sys
    import argparse
    
    parser = argparse.ArgumentParser(description="Castle Crashers Save Editor CLI")
    parser.add_argument("save_path", help="Path to cc_save.dat")
    parser.add_argument("steam_id", help="Steam ID64")
    parser.add_argument("--character", help="Name or index of character to modify/view")
    parser.add_argument("--gold", type=int, help="Set gold amount")
    parser.add_argument("--level", type=int, help="Set level (1-99)")
    parser.add_argument("--xp", type=int, help="Set XP amount")
    parser.add_argument("--unlock", action="store_true", help="Unlock character")
    parser.add_argument("--max-stats", action="store_true", help="Set strength, defense, magic, agility to 25")
    parser.add_argument("--boost-all", action="store_true", help="Unlock all characters and set gold, level, and stats to max")
    
    args = parser.parse_args()

    editor = CCSaveEditor(args.save_path, args.steam_id)
    try:
        editor.load()
        print("Successfully loaded and decrypted save file.")

        if args.boost_all:
            editor.set_global_data(unlock_pets=True, unlock_weapons=True, enable_items=True, unlock_arenas=True)
            for idx in range(len(editor.CHARACTERS)):
                editor.set_character_data(
                    idx, gold=99999, level=99, xp=120000, unlocked=True, 
                    strength=25, defense=25, magic=25, agility=25, skull=255,
                    relics=[True] * 8
                )
            print("Successfully boosted all characters to max level, stats, skull, and gold.")
            editor.save()
            print("Save file encrypted and updated successfully.")
            sys.exit(0)

        # Resolve character
        char_idx = None
        if args.character:
            if args.character.isdigit():
                char_idx = int(args.character)
            else:
                try:
                    char_idx = [c.lower() for c in editor.CHARACTERS].index(args.character.lower())
                except ValueError:
                    print(f"Unknown character: {args.character}")
                    sys.exit(1)
        
        if char_idx is not None:
            # Modify character data if arguments provided
            if args.gold is not None or args.level is not None or args.xp is not None or args.unlock or args.max_stats:
                strength = 25 if args.max_stats else None
                defense = 25 if args.max_stats else None
                magic = 25 if args.max_stats else None
                agility = 25 if args.max_stats else None
                
                editor.set_character_data(
                    char_idx,
                    gold=args.gold,
                    level=args.level,
                    xp=args.xp,
                    unlocked=True if args.unlock else None,
                    strength=strength,
                    defense=defense,
                    magic=magic,
                    agility=agility
                )
                print(f"Updated data for {editor.CHARACTERS[char_idx]}.")
                editor.save()
                print("Save file encrypted and updated successfully.")
            else:
                # View character data
                char = editor.get_character_data(char_idx)
                print(f"Character: {char['name']}")
                print(f"  Unlocked:  {char['unlocked']}")
                print(f"  Level:     {char['level']}")
                print(f"  XP:        {char['xp']}")
                print(f"  Gold:      {char['gold']}")
                print(f"  Strength:  {char['strength']}")
                print(f"  Defense:   {char['defense']}")
                print(f"  Magic:     {char['magic']}")
                print(f"  Agility:   {char['agility']}")
        else:
            # Print general status and character list
            print("\nAvailable Characters:")
            for idx, c in enumerate(editor.CHARACTERS):
                char = editor.get_character_data(idx)
                unlocked_str = "Unlocked" if char["unlocked"] else "Locked"
                print(f" [{idx:02d}] {c:<25} (Lv.{char['level']}, Gold: {char['gold']}, {unlocked_str})")
            print("\nUse --character to view/edit a specific character. Use --boost-all to unlock/max everything.")

    except Exception as e:
        print(f"Error: {e}")
