import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from cc_save_editor import CCSaveEditor

class CCSaveGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Castle Crashers Save Editor Pro")
        self.root.geometry("980x780")
        self.root.configure(bg="#18181b")

        # Set dark theme styling
        self.style = ttk.Style()
        self.style.theme_use("clam")
        
        # Configure colors
        self.bg_color = "#18181b"
        self.panel_color = "#202024"
        self.accent_color = "#c26d52"
        self.text_color = "#e7e5e4"
        self.input_bg = "#27272a"
        
        self.style.configure(".", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TLabel", background=self.bg_color, foreground=self.text_color, font=("Outfit", 10))
        self.style.configure("TEntry", fieldbackground=self.input_bg, foreground=self.text_color, bordercolor="#3f3f46")
        self.style.configure("TButton", background=self.accent_color, foreground="#ffffff", bordercolor=self.accent_color, font=("Outfit", 10, "bold"))
        self.style.map("TButton", background=[("active", "#a8553d")])
        self.style.configure("TCheckbutton", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TFrame", background=self.bg_color)
        self.style.configure("TLabelframe", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TLabelframe.Label", background=self.bg_color, foreground=self.accent_color, font=("Outfit", 10, "bold"))
        self.style.configure("TCombobox", fieldbackground=self.input_bg, background=self.bg_color, foreground=self.text_color)
        
        # State variables
        self.save_path_var = tk.StringVar(value=r"C:\Users\abc\AppData\Roaming\GSE Saves\204360\remote\cc_save.dat")
        self.steam_id_var = tk.StringVar(value="76561197960287930")
        self.editor = None
        self.selected_char_idx = None
        self.is_loading_data = False  # Flag to prevent trace updates during load
        
        # Initialize UI layout
        self.create_widgets()
        
        # Auto-load on startup if file exists
        self.load_save_file()

    def create_widgets(self):
        # 1. Top Panel: File and Steam ID Selection
        top_frame = tk.Frame(self.root, bg=self.panel_color, bd=1, relief=tk.SOLID)
        top_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(top_frame, text="Save File Path:", bg=self.panel_color, fg=self.text_color, font=("Outfit", 10, "bold")).grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
        path_entry = ttk.Entry(top_frame, textvariable=self.save_path_var, width=60)
        path_entry.grid(row=0, column=1, padx=5, pady=10, sticky=tk.EW)
        
        browse_btn = ttk.Button(top_frame, text="Browse...", command=self.browse_file)
        browse_btn.grid(row=0, column=2, padx=5, pady=10)
        
        tk.Label(top_frame, text="Steam ID64:", bg=self.panel_color, fg=self.text_color, font=("Outfit", 10, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        id_entry = ttk.Entry(top_frame, textvariable=self.steam_id_var, width=30)
        id_entry.grid(row=1, column=1, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        load_btn = ttk.Button(top_frame, text="Load / Decrypt Save", command=self.load_save_file)
        load_btn.grid(row=1, column=2, padx=5, pady=5, sticky=tk.E)

        # 2. Main Work Area: Left (Character List) & Right (Stats Editor / Global settings)
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Left Panel - Character selection list box
        left_frame = ttk.LabelFrame(main_frame, text=" Characters & Profile ")
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10), pady=5)
        
        self.char_listbox = tk.Listbox(
            left_frame, bg=self.input_bg, fg=self.text_color, 
            selectbackground=self.accent_color, selectforeground="#ffffff", 
            font=("Outfit", 10), bd=0, highlightthickness=0, width=28
        )
        self.char_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.char_listbox.bind("<<ListboxSelect>>", self.on_character_select)
        
        scrollbar = ttk.Scrollbar(left_frame, orient=tk.VERTICAL, command=self.char_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.char_listbox.config(yscrollcommand=scrollbar.set)

        # Right Panel - Container for the edit views
        self.right_container = tk.Frame(main_frame, bg=self.bg_color)
        self.right_container.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, pady=5)

        # A: Character Edit Frame
        self.char_edit_frame = ttk.LabelFrame(self.right_container, text=" Edit Character Stats ")
        self.char_edit_frame.columnconfigure(1, weight=1)
        self.char_edit_frame.columnconfigure(3, weight=1)
        
        # Core Stats fields (Column 1)
        self.unlocked_var = tk.BooleanVar()
        self.unlock_check = ttk.Checkbutton(self.char_edit_frame, text="Unlocked", variable=self.unlocked_var, command=self.update_unlock_state)
        self.unlock_check.grid(row=0, column=0, columnspan=2, padx=15, pady=10, sticky=tk.W)
        
        tk.Label(self.char_edit_frame, text="Level (1-99):").grid(row=1, column=0, padx=15, pady=5, sticky=tk.W)
        self.level_var = tk.StringVar()
        self.level_entry = ttk.Entry(self.char_edit_frame, textvariable=self.level_var, width=15)
        self.level_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        self.level_var.trace_add("write", lambda *a: self.on_field_change("level", self.level_var.get()))
        
        tk.Label(self.char_edit_frame, text="XP:").grid(row=2, column=0, padx=15, pady=5, sticky=tk.W)
        self.xp_var = tk.StringVar()
        self.xp_entry = ttk.Entry(self.char_edit_frame, textvariable=self.xp_var, width=15)
        self.xp_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        self.xp_var.trace_add("write", lambda *a: self.on_field_change("xp", self.xp_var.get()))
        
        tk.Label(self.char_edit_frame, text="Gold:").grid(row=3, column=0, padx=15, pady=5, sticky=tk.W)
        self.gold_var = tk.StringVar()
        self.gold_entry = ttk.Entry(self.char_edit_frame, textvariable=self.gold_var, width=15)
        self.gold_entry.grid(row=3, column=1, padx=5, pady=5, sticky=tk.W)
        self.gold_var.trace_add("write", lambda *a: self.on_field_change("gold", self.gold_var.get()))
        
        # Skill points attributes
        tk.Label(self.char_edit_frame, text="Attributes (0-25):", font=("Outfit", 10, "bold"), fg=self.accent_color).grid(row=4, column=0, columnspan=2, padx=15, pady=10, sticky=tk.W)
        
        # Strength
        tk.Label(self.char_edit_frame, text="Strength:").grid(row=5, column=0, padx=15, pady=5, sticky=tk.W)
        self.str_var = tk.IntVar()
        self.str_slider = tk.Scale(self.char_edit_frame, from_=0, to=25, orient=tk.HORIZONTAL, variable=self.str_var, bg=self.bg_color, fg=self.text_color, troughcolor=self.input_bg, activebackground=self.accent_color, highlightthickness=0, command=lambda v: self.on_field_change("strength", v))
        self.str_slider.grid(row=5, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Defense
        tk.Label(self.char_edit_frame, text="Defense:").grid(row=6, column=0, padx=15, pady=5, sticky=tk.W)
        self.def_var = tk.IntVar()
        self.def_slider = tk.Scale(self.char_edit_frame, from_=0, to=25, orient=tk.HORIZONTAL, variable=self.def_var, bg=self.bg_color, fg=self.text_color, troughcolor=self.input_bg, activebackground=self.accent_color, highlightthickness=0, command=lambda v: self.on_field_change("defense", v))
        self.def_slider.grid(row=6, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Magic
        tk.Label(self.char_edit_frame, text="Magic:").grid(row=7, column=0, padx=15, pady=5, sticky=tk.W)
        self.mag_var = tk.IntVar()
        self.mag_slider = tk.Scale(self.char_edit_frame, from_=0, to=25, orient=tk.HORIZONTAL, variable=self.mag_var, bg=self.bg_color, fg=self.text_color, troughcolor=self.input_bg, activebackground=self.accent_color, highlightthickness=0, command=lambda v: self.on_field_change("magic", v))
        self.mag_slider.grid(row=7, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Agility
        tk.Label(self.char_edit_frame, text="Agility:").grid(row=8, column=0, padx=15, pady=5, sticky=tk.W)
        self.agi_var = tk.IntVar()
        self.agi_slider = tk.Scale(self.char_edit_frame, from_=0, to=25, orient=tk.HORIZONTAL, variable=self.agi_var, bg=self.bg_color, fg=self.text_color, troughcolor=self.input_bg, activebackground=self.accent_color, highlightthickness=0, command=lambda v: self.on_field_change("agility", v))
        self.agi_slider.grid(row=8, column=1, padx=5, pady=5, sticky=tk.EW)

        # Equipment & Progress fields (Column 2)
        tk.Label(self.char_edit_frame, text="Equipped Weapon:").grid(row=1, column=2, padx=15, pady=5, sticky=tk.W)
        self.weapon_combo = ttk.Combobox(self.char_edit_frame, values=CCSaveEditor.WEAPONS, state="readonly", width=25)
        self.weapon_combo.grid(row=1, column=3, padx=5, pady=5, sticky=tk.W)
        self.weapon_combo.bind("<<ComboboxSelected>>", lambda e: self.on_field_change("weapon", self.weapon_combo.current()))

        tk.Label(self.char_edit_frame, text="Equipped Pet:").grid(row=2, column=2, padx=15, pady=5, sticky=tk.W)
        self.pet_combo = ttk.Combobox(self.char_edit_frame, values=CCSaveEditor.PETS, state="readonly", width=25)
        self.pet_combo.grid(row=2, column=3, padx=5, pady=5, sticky=tk.W)
        self.pet_combo.bind("<<ComboboxSelected>>", lambda e: self.on_field_change("pet", self.pet_combo.current()))

        # Consumable items
        tk.Label(self.char_edit_frame, text="Potions:").grid(row=3, column=2, padx=15, pady=5, sticky=tk.W)
        self.potions_var = tk.StringVar()
        self.potions_entry = ttk.Entry(self.char_edit_frame, textvariable=self.potions_var, width=10)
        self.potions_entry.grid(row=3, column=3, padx=5, pady=5, sticky=tk.W)
        self.potions_var.trace_add("write", lambda *a: self.on_field_change("potions", self.potions_var.get()))

        tk.Label(self.char_edit_frame, text="Bombs:").grid(row=4, column=2, padx=15, pady=5, sticky=tk.W)
        self.bombs_var = tk.StringVar()
        self.bombs_entry = ttk.Entry(self.char_edit_frame, textvariable=self.bombs_var, width=10)
        self.bombs_entry.grid(row=4, column=3, padx=5, pady=5, sticky=tk.W)
        self.bombs_var.trace_add("write", lambda *a: self.on_field_change("bombs", self.bombs_var.get()))

        tk.Label(self.char_edit_frame, text="Sandwiches:").grid(row=5, column=2, padx=15, pady=5, sticky=tk.W)
        self.sandwiches_var = tk.StringVar()
        self.sandwiches_entry = ttk.Entry(self.char_edit_frame, textvariable=self.sandwiches_var, width=10)
        self.sandwiches_entry.grid(row=5, column=3, padx=5, pady=5, sticky=tk.W)
        self.sandwiches_var.trace_add("write", lambda *a: self.on_field_change("sandwiches", self.sandwiches_var.get()))

        tk.Label(self.char_edit_frame, text="Campaign Details:", font=("Outfit", 10, "bold"), fg=self.accent_color).grid(row=6, column=2, columnspan=2, padx=15, pady=10, sticky=tk.W)

        # Normal Campaign Checkpoint
        tk.Label(self.char_edit_frame, text="Normal Checkpoint:").grid(row=7, column=2, padx=15, pady=5, sticky=tk.W)
        self.normal_lvl_combo = ttk.Combobox(self.char_edit_frame, values=CCSaveEditor.LEVELS, state="readonly", width=25)
        self.normal_lvl_combo.grid(row=7, column=3, padx=5, pady=5, sticky=tk.W)
        self.normal_lvl_combo.bind("<<ComboboxSelected>>", lambda e: self.on_field_change("normal_lvl", self.normal_lvl_combo.current()))

        # Insane Mode Unlocked checkbox & Campaign checkpoint
        self.insane_unlocked_var = tk.BooleanVar()
        self.insane_unlocked_check = ttk.Checkbutton(self.char_edit_frame, text="Insane Mode Unlocked", variable=self.insane_unlocked_var, command=self.update_insane_unlock)
        self.insane_unlocked_check.grid(row=8, column=2, columnspan=2, padx=15, pady=5, sticky=tk.W)

        tk.Label(self.char_edit_frame, text="Insane Checkpoint:").grid(row=9, column=2, padx=15, pady=5, sticky=tk.W)
        self.insane_lvl_combo = ttk.Combobox(self.char_edit_frame, values=CCSaveEditor.LEVELS, state="readonly", width=25)
        self.insane_lvl_combo.grid(row=9, column=3, padx=5, pady=5, sticky=tk.W)
        self.insane_lvl_combo.bind("<<ComboboxSelected>>", lambda e: self.on_field_change("insane_lvl", self.insane_lvl_combo.current()))

        # Skull Badge
        tk.Label(self.char_edit_frame, text="Completion Skull:").grid(row=10, column=0, padx=15, pady=5, sticky=tk.W)
        self.skull_combo = ttk.Combobox(self.char_edit_frame, values=["None", "White Skull (Normal Campaign)", "Gold Skull (Insane Campaign)"], state="readonly", width=25)
        self.skull_combo.grid(row=10, column=1, padx=5, pady=5, sticky=tk.W)
        self.skull_combo.bind("<<ComboboxSelected>>", self.on_skull_change)

        # Relic Checkboxes (Character Relics)
        relics_frame = ttk.LabelFrame(self.char_edit_frame, text=" Character Relics / Story Items ")
        relics_frame.grid(row=11, column=2, columnspan=2, padx=15, pady=10, sticky=tk.NSEW)
        
        self.relic_vars = []
        relic_names = ["Compass (N)", "Wheel (N)", "Telescope (N)", "Horn (N)", "Compass (I)", "Wheel (I)", "Telescope (I)", "Horn (I)"]
        for idx, name in enumerate(relic_names):
            var = tk.BooleanVar()
            self.relic_vars.append(var)
            cb = ttk.Checkbutton(relics_frame, text=name, variable=var, command=self.update_relics)
            cb.grid(row=idx // 2, column=idx % 2, padx=5, pady=2, sticky=tk.W)

        # Quick action buttons for selected character
        self.boost_char_btn = ttk.Button(self.char_edit_frame, text="Boost Selected Character", command=self.boost_selected_character)
        self.boost_char_btn.grid(row=12, column=0, columnspan=2, padx=15, pady=15, sticky=tk.W)

        # B: Global Settings Edit Frame
        self.global_edit_frame = ttk.LabelFrame(self.right_container, text=" Global Settings & Customizations ")
        
        self.gore_var = tk.BooleanVar()
        self.gore_check = ttk.Checkbutton(self.global_edit_frame, text="Gore / Blood Effects Enabled", variable=self.gore_var, command=lambda: self.on_global_field_change("gore", self.gore_var.get()))
        self.gore_check.grid(row=0, column=0, columnspan=2, padx=15, pady=10, sticky=tk.W)

        self.vibration_var = tk.BooleanVar()
        self.vibration_check = ttk.Checkbutton(self.global_edit_frame, text="Controller Vibration Enabled", variable=self.vibration_var, command=lambda: self.on_global_field_change("vibration", self.vibration_var.get()))
        self.vibration_check.grid(row=1, column=0, columnspan=2, padx=15, pady=10, sticky=tk.W)

        tk.Label(self.global_edit_frame, text="Music Volume (0-10):").grid(row=2, column=0, padx=15, pady=5, sticky=tk.W)
        self.music_vol_var = tk.IntVar()
        self.music_vol_scale = tk.Scale(self.global_edit_frame, from_=0, to=10, orient=tk.HORIZONTAL, variable=self.music_vol_var, bg=self.bg_color, fg=self.text_color, troughcolor=self.input_bg, activebackground=self.accent_color, highlightthickness=0, command=lambda v: self.on_global_field_change("music_vol", v))
        self.music_vol_scale.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)

        # Back Off Barbarian Score Section
        tk.Label(self.global_edit_frame, text="Back Off Barbarian (Mini-game) Score:", font=("Outfit", 10, "bold"), fg=self.accent_color).grid(row=3, column=0, columnspan=2, padx=15, pady=15, sticky=tk.W)

        tk.Label(self.global_edit_frame, text="High Score (seconds):").grid(row=4, column=0, padx=15, pady=5, sticky=tk.W)
        self.bob_time_var = tk.StringVar()
        self.bob_time_entry = ttk.Entry(self.global_edit_frame, textvariable=self.bob_time_var, width=15)
        self.bob_time_entry.grid(row=4, column=1, padx=5, pady=5, sticky=tk.W)
        self.bob_time_var.trace_add("write", lambda *a: self.on_global_field_change("bob_time", self.bob_time_var.get()))

        tk.Label(self.global_edit_frame, text="Achieved By Character:").grid(row=5, column=0, padx=15, pady=5, sticky=tk.W)
        self.bob_char_combo = ttk.Combobox(self.global_edit_frame, values=["None"] + CCSaveEditor.CHARACTERS, state="readonly", width=25)
        self.bob_char_combo.grid(row=5, column=1, padx=5, pady=5, sticky=tk.W)
        self.bob_char_combo.bind("<<ComboboxSelected>>", lambda e: self.on_global_field_change("bob_char", self.bob_char_combo.current()))

        # Show character editing initially
        self.char_edit_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 3. Bottom Panel: Global Buttons and Actions
        bottom_frame = tk.Frame(self.root, bg=self.panel_color, bd=1, relief=tk.SOLID)
        bottom_frame.pack(fill=tk.X, padx=10, pady=(5, 10))
        
        # Sub-frame for global unlock buttons
        global_unlocks = tk.Frame(bottom_frame, bg=self.panel_color)
        global_unlocks.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        self.weapons_unlock_btn = ttk.Button(global_unlocks, text="⚔️ Unlock All Weapons", command=self.unlock_all_weapons_globally)
        self.weapons_unlock_btn.pack(side=tk.LEFT, padx=5)

        self.pets_unlock_btn = ttk.Button(global_unlocks, text="🐾 Unlock All Pets", command=self.unlock_all_pets_globally)
        self.pets_unlock_btn.pack(side=tk.LEFT, padx=5)

        self.items_unlock_btn = ttk.Button(global_unlocks, text="🏹 Enable Basic Items", command=self.enable_basic_items_globally)
        self.items_unlock_btn.pack(side=tk.LEFT, padx=5)

        self.arenas_unlock_btn = ttk.Button(global_unlocks, text="🏟️ Unlock Arenas", command=self.unlock_arenas_globally)
        self.arenas_unlock_btn.pack(side=tk.LEFT, padx=5)

        # Right side actions
        actions_frame = tk.Frame(bottom_frame, bg=self.panel_color)
        actions_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.boost_all_btn = ttk.Button(actions_frame, text="🔥 Boost All (Level/Stats/Gold/Skull)", command=self.boost_all_characters)
        self.boost_all_btn.pack(side=tk.LEFT, padx=5)
        
        self.save_btn = ttk.Button(actions_frame, text="💾 Save Changes", command=self.save_file)
        self.save_btn.pack(side=tk.LEFT, padx=5)

    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select cc_save.dat",
            filetypes=[("Save Files", "*.dat"), ("All Files", "*.*")]
        )
        if filename:
            self.save_path_var.set(filename)

    def load_save_file(self):
        path = self.save_path_var.get()
        steam_id = self.steam_id_var.get()
        
        if not path or not os.path.exists(path):
            return
            
        if not steam_id or len(steam_id) < 10:
            return

        try:
            self.editor = CCSaveEditor(path, steam_id)
            self.editor.load()
            
            # Populate character list
            self.char_listbox.delete(0, tk.END)
            for idx, char_name in enumerate(self.editor.CHARACTERS):
                char_data = self.editor.get_character_data(idx)
                unlocked_str = "" if char_data["unlocked"] else " [LOCKED]"
                self.char_listbox.insert(tk.END, f"{char_name}{unlocked_str}")
                
            # Add Global settings entry
            self.char_listbox.insert(tk.END, "⚙️ [ PROFILE & OPTIONS ]")
                
            self.selected_char_idx = None
            self.set_fields_state(tk.DISABLED)
            
            # Hide global edit panel if loaded a new file
            self.global_edit_frame.pack_forget()
            self.char_edit_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            messagebox.showinfo("Success", "Save file loaded and decrypted successfully.")
        except Exception as e:
            messagebox.showerror("Decryption Failed", f"Failed to decrypt save data.\nCheck if your Steam ID is correct.\n\nError: {e}")

    def on_character_select(self, event):
        selection = self.char_listbox.curselection()
        if not selection or not self.editor:
            return
            
        idx = selection[0]
        if idx == len(self.editor.CHARACTERS):
            # Global settings item
            self.selected_char_idx = -2
            self.char_edit_frame.pack_forget()
            self.global_edit_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
            self.load_global_settings()
        else:
            self.selected_char_idx = idx
            self.global_edit_frame.pack_forget()
            self.char_edit_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            self.load_character_data(self.selected_char_idx)

    def load_global_settings(self):
        if not self.editor:
            return
            
        self.is_loading_data = True
        g_data = self.editor.get_global_settings()
        
        self.gore_var.set(g_data["gore"])
        self.vibration_var.set(g_data["vibration"])
        self.music_vol_var.set(g_data["music_vol"])
        
        # Display Back Off Barbarian high score details
        # Time is saved in milliseconds, show as seconds
        self.bob_time_var.set(f"{g_data['bob_time'] / 1000.0:.2f}")
        
        char_idx = g_data["bob_char"]
        if char_idx >= 0 and char_idx < len(self.editor.CHARACTERS):
            self.bob_char_combo.set(self.editor.CHARACTERS[char_idx])
        else:
            self.bob_char_combo.set("None")
            
        self.is_loading_data = False

    def load_character_data(self, idx):
        if not self.editor:
            return
            
        self.is_loading_data = True
        char_data = self.editor.get_character_data(idx)
        
        self.set_fields_state(tk.NORMAL)
        
        self.unlocked_var.set(char_data["unlocked"])
        self.level_var.set(str(char_data["level"]))
        self.xp_var.set(str(char_data["xp"]))
        self.gold_var.set(str(char_data["gold"]))
        self.str_var.set(char_data["strength"])
        self.def_var.set(char_data["defense"])
        self.mag_var.set(char_data["magic"])
        self.agi_var.set(char_data["agility"])
        self.potions_var.set(str(char_data["potions"]))
        self.bombs_var.set(str(char_data["bombs"]))
        self.sandwiches_var.set(str(char_data["sandwiches"]))
        
        # Relic Checkboxes
        for i, val in enumerate(char_data["relics"]):
            self.relic_vars[i].set(val)

        # Comboboxes selections
        self.weapon_combo.set(self.weapon_combo["values"][char_data["weapon"]] if char_data["weapon"] < len(CCSaveEditor.WEAPONS) else "Unknown")
        self.pet_combo.set(self.pet_combo["values"][char_data["pet"]] if char_data["pet"] < len(CCSaveEditor.PETS) else "None")
        
        self.normal_lvl_combo.set(self.normal_lvl_combo["values"][char_data["normal_lvl"]] if char_data["normal_lvl"] < len(CCSaveEditor.LEVELS) else "Checkpoint 0")
        
        self.insane_unlocked_var.set(char_data["insane_unlocked"])
        self.insane_lvl_combo.set(self.insane_lvl_combo["values"][char_data["insane_lvl"]] if char_data["insane_lvl"] < len(CCSaveEditor.LEVELS) else "Checkpoint 0")
        
        # Skull setting
        skull_val = char_data["skull"]
        if skull_val == 1:
            self.skull_combo.set("White Skull (Normal Campaign)")
        elif skull_val == 255:
            self.skull_combo.set("Gold Skull (Insane Campaign)")
        else:
            self.skull_combo.set("None")
            
        self.is_loading_data = False
        
        # Lock status check
        if not char_data["unlocked"]:
            self.set_fields_state(tk.DISABLED, lock_check_only=False)
            self.unlock_check.configure(state=tk.NORMAL)

    def update_unlock_state(self):
        if self.selected_char_idx is None or not self.editor or self.is_loading_data:
            return
        
        unlocked = self.unlocked_var.get()
        self.editor.set_character_data(self.selected_char_idx, unlocked=unlocked)
        
        # Refresh character list layout
        name = self.editor.CHARACTERS[self.selected_char_idx]
        unlocked_str = "" if unlocked else " [LOCKED]"
        self.char_listbox.delete(self.selected_char_idx)
        self.char_listbox.insert(self.selected_char_idx, f"{name}{unlocked_str}")
        self.char_listbox.select_set(self.selected_char_idx)
        
        if unlocked:
            self.set_fields_state(tk.NORMAL)
        else:
            self.set_fields_state(tk.DISABLED)
            self.unlock_check.configure(state=tk.NORMAL)

    def update_insane_unlock(self):
        if self.selected_char_idx is None or not self.editor or self.is_loading_data:
            return
        self.editor.set_character_data(self.selected_char_idx, insane_unlocked=self.insane_unlocked_var.get())

    def update_relics(self):
        if self.selected_char_idx is None or not self.editor or self.is_loading_data:
            return
        relics_list = [v.get() for v in self.relic_vars]
        self.editor.set_character_data(self.selected_char_idx, relics=relics_list)

    def on_skull_change(self, event):
        if self.selected_char_idx is None or not self.editor or self.is_loading_data:
            return
        sel = self.skull_combo.get()
        val = 0
        if "White Skull" in sel:
            val = 1
        elif "Gold Skull" in sel:
            val = 255
        self.editor.set_character_data(self.selected_char_idx, skull=val)

    def on_field_change(self, field_name, value):
        if self.selected_char_idx is None or not self.editor or self.is_loading_data:
            return
            
        try:
            if field_name == "level":
                val = int(value) if value else 1
                self.editor.set_character_data(self.selected_char_idx, level=val)
            elif field_name == "xp":
                val = int(value) if value else 0
                self.editor.set_character_data(self.selected_char_idx, xp=val)
            elif field_name == "gold":
                val = int(value) if value else 0
                self.editor.set_character_data(self.selected_char_idx, gold=val)
            elif field_name == "potions":
                val = int(value) if value else 0
                self.editor.set_character_data(self.selected_char_idx, potions=val)
            elif field_name == "bombs":
                val = int(value) if value else 0
                self.editor.set_character_data(self.selected_char_idx, bombs=val)
            elif field_name == "sandwiches":
                val = int(value) if value else 0
                self.editor.set_character_data(self.selected_char_idx, sandwiches=val)
            elif field_name == "strength":
                self.editor.set_character_data(self.selected_char_idx, strength=int(value))
            elif field_name == "defense":
                self.editor.set_character_data(self.selected_char_idx, defense=int(value))
            elif field_name == "magic":
                self.editor.set_character_data(self.selected_char_idx, magic=int(value))
            elif field_name == "agility":
                self.editor.set_character_data(self.selected_char_idx, agility=int(value))
            elif field_name == "weapon":
                self.editor.set_character_data(self.selected_char_idx, weapon=int(value))
            elif field_name == "pet":
                self.editor.set_character_data(self.selected_char_idx, pet=int(value))
            elif field_name == "normal_lvl":
                self.editor.set_character_data(self.selected_char_idx, normal_lvl=int(value))
            elif field_name == "insane_lvl":
                self.editor.set_character_data(self.selected_char_idx, insane_lvl=int(value))
        except ValueError:
            pass # Ignore malformed inputs while typing

    def on_global_field_change(self, field_name, value):
        if not self.editor or self.is_loading_data:
            return
            
        try:
            if field_name == "gore":
                self.editor.set_global_settings(gore=value)
            elif field_name == "vibration":
                self.editor.set_global_settings(vibration=value)
            elif field_name == "music_vol":
                self.editor.set_global_settings(music_vol=int(value))
            elif field_name == "bob_time":
                # Convert seconds back to milliseconds in the file
                val = int(float(value) * 1000.0) if value else 0
                self.editor.set_global_settings(bob_time=val)
            elif field_name == "bob_char":
                # Combobox has "None" + Characters, so current index - 1 is character index
                char_idx = int(value) - 1
                self.editor.set_global_settings(bob_char=char_idx)
        except ValueError:
            pass

    def set_fields_state(self, state, lock_check_only=False):
        widgets = [
            self.level_entry, self.xp_entry, self.gold_entry,
            self.str_slider, self.def_slider, self.mag_slider, self.agi_slider,
            self.potions_entry, self.bombs_entry, self.sandwiches_entry,
            self.weapon_combo, self.pet_combo, self.normal_lvl_combo,
            self.insane_lvl_combo, self.insane_unlocked_check, self.skull_combo,
            self.boost_char_btn
        ]
        
        if not lock_check_only:
            self.unlock_check.configure(state=state)
            
        for widget in widgets:
            widget.configure(state=state)

    def boost_selected_character(self):
        if self.selected_char_idx is None or not self.editor:
            return
            
        self.editor.set_character_data(
            self.selected_char_idx,
            unlocked=True, level=99, xp=120000, gold=99999,
            strength=25, defense=25, magic=25, agility=25,
            potions=5, bombs=9, sandwiches=9,
            normal_lvl=len(CCSaveEditor.LEVELS) - 1,
            insane_unlocked=True, insane_lvl=len(CCSaveEditor.LEVELS) - 1,
            skull=255, relics=[True] * 8
        )
        self.load_character_data(self.selected_char_idx)
        
        # Refresh list name
        name = self.editor.CHARACTERS[self.selected_char_idx]
        self.char_listbox.delete(self.selected_char_idx)
        self.char_listbox.insert(self.selected_char_idx, name)
        self.char_listbox.select_set(self.selected_char_idx)
        
        messagebox.showinfo("Success", f"{name} boosted successfully!")

    def unlock_all_weapons_globally(self):
        if not self.editor:
            messagebox.showerror("Error", "Please load a save file first.")
            return
        self.editor.set_global_data(unlock_weapons=True)
        messagebox.showinfo("Success", "All main and DLC weapons unlocked globally in memory.")

    def unlock_all_pets_globally(self):
        if not self.editor:
            messagebox.showerror("Error", "Please load a save file first.")
            return
        self.editor.set_global_data(unlock_pets=True)
        messagebox.showinfo("Success", "All pets unlocked globally in memory.")

    def enable_basic_items_globally(self):
        if not self.editor:
            messagebox.showerror("Error", "Please load a save file first.")
            return
        self.editor.set_global_data(enable_items=True)
        messagebox.showinfo("Success", "Bow, shovel, and boomerang enabled globally.")

    def unlock_arenas_globally(self):
        if not self.editor:
            messagebox.showerror("Error", "Please load a save file first.")
            return
        self.editor.set_global_data(unlock_arenas=True)
        messagebox.showinfo("Success", "All multiplayer battle arenas unlocked globally.")

    def boost_all_characters(self):
        if not self.editor:
            messagebox.showerror("Error", "Please load a save file first.")
            return
            
        if not messagebox.askyesno("Confirm Boost All", "Are you sure you want to unlock and max out all characters?\nThis will modify the stats of all 42 slots."):
            return

        self.editor.set_global_data(unlock_pets=True, unlock_weapons=True, enable_items=True, unlock_arenas=True)
        for idx in range(len(self.editor.CHARACTERS)):
            self.editor.set_character_data(
                idx,
                unlocked=True, level=99, xp=120000, gold=99999,
                strength=25, defense=25, magic=25, agility=25,
                potions=5, bombs=9, sandwiches=9,
                normal_lvl=len(CCSaveEditor.LEVELS) - 1,
                insane_unlocked=True, insane_lvl=len(CCSaveEditor.LEVELS) - 1,
                skull=255, relics=[True] * 8
            )
            
        # Refresh listbox layout
        self.char_listbox.delete(0, tk.END)
        for name in self.editor.CHARACTERS:
            self.char_listbox.insert(tk.END, name)
            
        self.selected_char_idx = None
        self.set_fields_state(tk.DISABLED)
        messagebox.showinfo("Success", "All characters unlocked and maxed out in memory.")

    def save_file(self):
        if not self.editor:
            messagebox.showerror("Error", "No save data loaded to save.")
            return

        try:
            # Backup original file before writing changes
            orig_path = self.editor.filepath
            backup_path = orig_path + ".bak"
            if not os.path.exists(backup_path):
                import shutil
                shutil.copy2(orig_path, backup_path)
                
            self.editor.save()
            messagebox.showinfo("Success", f"Save file updated successfully!\nOriginal backup saved as {backup_path}")
        except Exception as e:
            messagebox.showerror("Save Failed", f"Failed to save changes.\nError: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = CCSaveGUI(root)
    root.mainloop()
